# Orbis Vox website

Static, dependency-free newspaper site for GitHub Pages. The homepage, four category pages, About, Contact, search, and every article have their own route.

## Add an article
Add one object to `assets/articles.js` in `window.ORBIS_ARTICLES`. Required fields: `id`, `slug`, `title`, `category` (`news`, `opinion`, `people`, or `culture`), `categoryLabel`, `date`, `summary`, `author`, `content`, and `image` (use `null` if none). Then create `articles/<slug>/index.html` by copying an existing article page and changing the title and `data-slug`. Article body content is HTML inside the `content` field.

## Add a category
Add its key, heading, and introduction to the `cats` object in `assets/app.js`, and add its label and path to `navItems` in the same file. Copy a category route to `<category>/index.html` and set `data-category` to the new key. Assign new articles to that key. The shared JavaScript builds the navigation on every page.

## Run locally
Open `index.html` directly for basic viewing, or serve this folder with any static HTTP server (for example `python -m http.server 8000` from this directory) and visit `http://localhost:8000/`.

The contact page intentionally uses placeholders because no contact address was supplied. No newsletter, subscription, account, or registration feature is included.
